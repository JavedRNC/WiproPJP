public class Person
{
   String name;
   
   Person()
   {
      name = "No name currently";
   }
}