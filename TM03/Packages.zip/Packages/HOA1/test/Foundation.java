package test;

public class Foundation
{
	private int a;
	protected int b;
	int c;
	public int d;
}