import test.*;

class foundationSubClass extends Foundation
{
	
	public static void main(String[] args)
	{
		Foundation f = new Foundation();
		f.a = 1;
		f.b = 2;
		f.c = 3;
		f.d = 4;
	}
}