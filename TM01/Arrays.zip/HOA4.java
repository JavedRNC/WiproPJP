import java.util.*;

public class HOA4
{
	public static void main(String args[])
	{
		int asc[] = {45,65,99,98,76};
		for(int i=0;i<asc.length;i++)
		{
			char ch = (char)asc[i];
			System.out.print(ch+ " ");
		}
	}
}