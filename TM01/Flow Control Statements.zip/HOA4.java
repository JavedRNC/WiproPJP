import java.util.*;

public class HOA4
{
	public static void main(String args[])
	{
		char a = 'a';
	    char b = 'h';
		if(a<b)
			System.out.println(a+","+b);
		else
			System.out.println(b+","+a);
	}
}