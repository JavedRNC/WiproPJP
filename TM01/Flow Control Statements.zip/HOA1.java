import java.util.*;

public class HOA1
{
  public static void main(String[] args)
 {
   int num = Integer.parseInt(args[0]);
   if(num>0)
   {
	   System.out.println("Positive Number");
   }
   else if(num<0)
   {
	   System.out.println("Negative Number");
   }
   else if(num==0)
   {
	   System.out.println("Its a zero");
   }
  
 }
 
}