
public class Demo1 {

	public String stringConcat(String str1,String str2)
	{
		return str1+str2;
	}
}
